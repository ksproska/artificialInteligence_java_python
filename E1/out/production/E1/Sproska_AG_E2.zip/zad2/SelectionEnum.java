package zad2;

public enum SelectionEnum {
    TOURNAMENT, ROULETTE
}
