package consts;

public enum FutoshikiEnum {
    F4x4, F5x5, F6x6
}
