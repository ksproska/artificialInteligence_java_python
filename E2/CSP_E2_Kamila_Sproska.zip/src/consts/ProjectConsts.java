package consts;

public class ProjectConsts {
    public static String folderPath = "F:\\sztuczna_inteligencja\\E2\\src\\binary-futoshiki_dane_v1.0";
}
