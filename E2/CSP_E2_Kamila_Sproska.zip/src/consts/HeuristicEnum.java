package consts;

public interface HeuristicEnum {}
