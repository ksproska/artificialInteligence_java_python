package consts;

public enum BinaryEnum {
    B6x6, B8x8, B10x10
}

