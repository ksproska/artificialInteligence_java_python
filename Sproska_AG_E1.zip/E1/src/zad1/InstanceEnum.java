package zad1;

public enum InstanceEnum {
    EASY, FLAT, HARD
}
