package zad1;

enum DataEnum {
    COST, FLOW
}
